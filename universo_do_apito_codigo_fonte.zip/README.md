# Universo do Apito — app Android (base funcional)

Aplicativo Expo/React Native com identidade preto e dourado, autenticação por e-mail, banco online Supabase, cadastro de campeonatos, profissionais, jogos e compartilhamento de escala pelo menu nativo do Android (inclui WhatsApp quando instalado).

## O que já está incluído
- Login/cadastro de usuário Supabase.
- Cadastro de campeonatos e temporada.
- Cadastro de árbitros, anotadores, cronometristas, mesários e coordenadores.
- Campo de disponibilidade/observações dos profissionais.
- Cadastro de jogos, local, categoria e designação de equipe de arbitragem.
- Geração de texto da escala filtrada por campeonato.
- Compartilhamento pelo menu do Android para escolher WhatsApp ou outro app.
- Segurança por usuário com Row Level Security (RLS).

## Antes de usar: configurar o Supabase
1. Crie um projeto em https://supabase.com/.
2. No painel do projeto, abra **SQL Editor** e execute todo o arquivo `supabase/schema.sql`.
3. Em **Project Settings → API**, copie a Project URL e a chave pública `anon`/publishable. Nunca coloque a `service_role` no aplicativo.
4. Copie `.env.example` para `.env` e preencha:
   - `EXPO_PUBLIC_SUPABASE_URL`
   - `EXPO_PUBLIC_SUPABASE_ANON_KEY`
5. Em Authentication, configure os métodos de entrada desejados. Para testar cadastro, veja se a confirmação de e-mail está ativada.

## Rodar no Android
Requer Node.js LTS e npm.
```bash
npm install
npx expo start
```
Instale o **Expo Go** no Android para testar e leia o QR code. Para criar APK instalável, veja a seção seguinte.

## Gerar APK com EAS Build
1. Crie uma conta em https://expo.dev/ e instale EAS CLI:
```bash
npm install -g eas-cli
eas login
eas build:configure
```
2. Configure as variáveis de ambiente no ambiente EAS para o perfil de build (não comite chaves privadas).
3. Execute:
```bash
eas build --platform android --profile preview
```
4. Baixe o APK no link retornado pelo EAS. A configuração padrão pode gerar AAB em perfil de produção; para APK de teste, use um perfil `preview` com `android.buildType: "apk"` no `eas.json`.

Exemplo de `eas.json`:
```json
{
  "build": {
    "preview": {
      "distribution": "internal",
      "android": { "buildType": "apk" },
      "channel": "preview"
    },
    "production": {
      "autoIncrement": true
    }
  }
}
```

## WhatsApp
O app usa o compartilhamento nativo do Android. Ao tocar em “Enviar escala pelo WhatsApp”, escolha WhatsApp na lista. O envio final é confirmado pelo usuário dentro do WhatsApp; o app não envia mensagens silenciosamente nem precisa acessar contatos.

## Limitações desta primeira versão
- O campo de disponibilidade é informativo; ainda não existe calendário de disponibilidade por dia/horário nem bloqueio automático de conflitos.
- Não há edição/exclusão de cadastros na interface nesta versão inicial.
- Não há envio automático em segundo plano, criação de imagem/PDF da escala ou gestão de pagamentos.
- A conta Supabase, as chaves e a compilação APK precisam ser configuradas pelo responsável pelo projeto; este pacote é o código-fonte e não um APK já compilado.

## Segurança
- Use apenas a chave pública do Supabase no app.
- As políticas RLS restringem dados ao usuário autenticado.
- Para compartilhar uma escala, confira os nomes e designações antes de enviá-la.
