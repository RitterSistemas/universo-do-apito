import React, { useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, KeyboardAvoidingView, Platform, SafeAreaView, ScrollView, Share, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';
import { isSupabaseConfigured, supabase } from './src/supabase';
import { C } from './src/theme';

const tabs = ['Painel', 'Campeonatos', 'Árbitros', 'Jogos', 'Escalas'];
const blankMatch = { championship_id: '', match_date: '', match_time: '', venue: '', category: '', home_team: '', away_team: '', referee_1: '', referee_2: '', table_official: '', notes: '' };

export default function App() {
  const [tab, setTab] = useState('Painel');
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [championships, setChampionships] = useState([]);
  const [officials, setOfficials] = useState([]);
  const [matches, setMatches] = useState([]);
  const [champName, setChampName] = useState('');
  const [champSeason, setChampSeason] = useState('2026');
  const [officialName, setOfficialName] = useState('');
  const [officialRole, setOfficialRole] = useState('Árbitro');
  const [officialPhone, setOfficialPhone] = useState('');
  const [availability, setAvailability] = useState('Informar disponibilidade no cadastro');
  const [match, setMatch] = useState(blankMatch);
  const [shareChamp, setShareChamp] = useState('');
  const [localMode, setLocalMode] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => { if (session) loadAll(); }, [session]);

  async function signIn() {
    if (!supabase) { Alert.alert('Configuração necessária', 'Configure o Supabase seguindo o README.'); return; }
    if (!email.trim() || !password) { Alert.alert('Preencha os campos', 'Informe e-mail e senha.'); return; }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setLoading(false);
    if (error) Alert.alert('Não foi possível entrar', error.message);
  }
  async function signUp() {
    if (!supabase) { Alert.alert('Configuração necessária', 'Configure o Supabase seguindo o README.'); return; }
    if (!email.trim() || password.length < 6) { Alert.alert('Dados necessários', 'Informe e-mail e senha com pelo menos 6 caracteres.'); return; }
    setLoading(true);
    const { error } = await supabase.auth.signUp({ email: email.trim(), password });
    setLoading(false);
    Alert.alert(error ? 'Erro no cadastro' : 'Cadastro solicitado', error ? error.message : 'Verifique seu e-mail caso a confirmação esteja ativada.');
  }
  async function loadAll() {
    if (!supabase || !session) return;
    const [c, o, m] = await Promise.all([
      supabase.from('championships').select('*').order('created_at', { ascending: false }),
      supabase.from('officials').select('*').order('name'),
      supabase.from('matches').select('*').order('match_date').order('match_time')
    ]);
    if (c.error || o.error || m.error) {
      Alert.alert('Erro ao carregar', c.error?.message || o.error?.message || m.error?.message);
      return;
    }
    setChampionships(c.data || []); setOfficials(o.data || []); setMatches(m.data || []);
  }
  async function addChampionship() {
    if (!champName.trim()) return Alert.alert('Informe o nome', 'Digite o nome do campeonato.');
    const { error } = await supabase.from('championships').insert({ name: champName.trim(), season: champSeason.trim() || null });
    if (error) return Alert.alert('Erro ao salvar', error.message);
    setChampName(''); await loadAll(); Alert.alert('Salvo', 'Campeonato cadastrado.');
  }
  async function addOfficial() {
    if (!officialName.trim()) return Alert.alert('Informe o nome', 'Digite o nome do profissional.');
    const { error } = await supabase.from('officials').insert({
      name: officialName.trim(), role: officialRole, phone: officialPhone.trim() || null,
      availability_notes: availability.trim() || null
    });
    if (error) return Alert.alert('Erro ao salvar', error.message);
    setOfficialName(''); setOfficialPhone(''); await loadAll(); Alert.alert('Salvo', 'Profissional cadastrado.');
  }
  async function addMatch() {
    if (!match.championship_id || !match.match_date || !match.match_time || !match.home_team.trim() || !match.away_team.trim()) {
      return Alert.alert('Faltam dados', 'Selecione campeonato e informe data, horário e as duas equipes.');
    }
    const payload = { ...match, championship_id: match.championship_id,
      referee_1: match.referee_1 || null, referee_2: match.referee_2 || null,
      table_official: match.table_official || null, venue: match.venue || null,
      category: match.category || null, notes: match.notes || null };
    const { error } = await supabase.from('matches').insert(payload);
    if (error) return Alert.alert('Erro ao salvar', error.message);
    setMatch(blankMatch); await loadAll(); Alert.alert('Salvo', 'Jogo cadastrado.');
  }
  const selectedChamp = (id) => championships.find(x => x.id === id)?.name || 'Campeonato';
  const selectedOfficial = (id) => officials.find(x => x.id === id)?.name || '';
  const scaleText = useMemo(() => {
    const list = matches.filter(m => !shareChamp || m.championship_id === shareChamp);
    const grouped = {};
    list.forEach(m => {
      const key = `${m.match_date || 'Data a definir'}`;
      grouped[key] ||= []; grouped[key].push(m);
    });
    const lines = ['🏆 UNIVERSO DO APITO', 'ESCALA DE ARBITRAGEM', ''];
    Object.keys(grouped).sort().forEach(day => {
      lines.push(`📅 ${day}`);
      grouped[day].sort((a,b) => (a.match_time || '').localeCompare(b.match_time || '')).forEach(m => {
        lines.push(`⚽ ${m.match_time || '--:--'} | ${m.home_team} x ${m.away_team}`);
        lines.push(`🏆 ${selectedChamp(m.championship_id)}${m.category ? ' • '+m.category : ''}`);
        if (m.venue) lines.push(`📍 ${m.venue}`);
        lines.push(`🧑‍⚖️ Árbitro 1: ${selectedOfficial(m.referee_1) || 'A definir'}`);
        lines.push(`🧑‍⚖️ Árbitro 2: ${selectedOfficial(m.referee_2) || 'A definir'}`);
        lines.push(`📝 Mesa: ${selectedOfficial(m.table_official) || 'A definir'}`);
        if (m.notes) lines.push(`Obs.: ${m.notes}`);
        lines.push('');
      });
    });
    return lines.join('\n');
  }, [matches, championships, officials, shareChamp]);

  async function shareScale() {
    if (!matches.length) return Alert.alert('Sem jogos', 'Cadastre jogos antes de compartilhar a escala.');
    try { await Share.share({ message: scaleText, title: 'Escala de Arbitragem - Universo do Apito' }); }
    catch (e) { Alert.alert('Erro ao compartilhar', e.message); }
  }
  function field(label, value, onChangeText, placeholder = '', extra = {}) {
    return <View style={styles.field} key={label}><Text style={styles.label}>{label}</Text><TextInput value={value} onChangeText={onChangeText} placeholder={placeholder || label} placeholderTextColor={C.muted} style={styles.input} {...extra}/></View>;
  }
  function pickRow(label, items, value, onPick) {
    return <View style={styles.field} key={label}><Text style={styles.label}>{label}</Text><ScrollView horizontal showsHorizontalScrollIndicator={false}><View style={styles.pills}>{items.map(item => <TouchableOpacity key={item.id || item} onPress={() => onPick(item.id || item)} style={[styles.pill, value === (item.id || item) && styles.pillActive]}><Text style={[styles.pillText, value === (item.id || item) && styles.pillTextActive]}>{item.name || item}</Text></TouchableOpacity>)}</View></ScrollView></View>;
  }
  function button(label, onPress, secondary = false) {
    return <TouchableOpacity onPress={onPress} style={[styles.button, secondary && styles.buttonSecondary]}><Text style={[styles.buttonText, secondary && styles.buttonTextSecondary]}>{label}</Text></TouchableOpacity>;
  }
  function card(title, subtitle, right) {
    return <View style={styles.item} key={title + subtitle}><View style={{ flex: 1 }}><Text style={styles.itemTitle}>{title}</Text><Text style={styles.itemSub}>{subtitle}</Text></View>{right}</View>;
  }
  function content() {
    if (tab === 'Painel') return <View>
      <Text style={styles.hero}>Sua arbitragem, organizada.</Text><Text style={styles.subhero}>Gerencie campeonatos, profissionais e escalas em um só lugar.</Text>
      <View style={styles.stats}><View style={styles.stat}><Text style={styles.statNum}>{championships.length}</Text><Text style={styles.statLabel}>Campeonatos</Text></View><View style={styles.stat}><Text style={styles.statNum}>{officials.length}</Text><Text style={styles.statLabel}>Profissionais</Text></View><View style={styles.stat}><Text style={styles.statNum}>{matches.length}</Text><Text style={styles.statLabel}>Jogos</Text></View></View>
      <Text style={styles.section}>Próximos jogos</Text>{matches.slice(0,4).map(m => card(`${m.home_team} x ${m.away_team}`, `${m.match_date} • ${m.match_time} • ${selectedChamp(m.championship_id)}`))}
      {button('Compartilhar escala no WhatsApp', shareScale)}
      {!isSupabaseConfigured && <Text style={styles.warning}>Modo de configuração: conecte o banco Supabase conforme o README para ativar os dados online.</Text>}
    </View>;
    if (tab === 'Campeonatos') return <View><Text style={styles.section}>Novo campeonato</Text>{field('Nome do campeonato', champName, setChampName, 'Ex.: Municipal de Futsal')}{field('Temporada/ano', champSeason, setChampSeason, '2026')}{button('Salvar campeonato', addChampionship)}<Text style={styles.section}>Cadastrados ({championships.length})</Text>{championships.map(c => card(c.name, c.season || 'Temporada não informada'))}</View>;
    if (tab === 'Árbitros') return <View><Text style={styles.section}>Novo profissional</Text>{field('Nome completo', officialName, setOfficialName, 'Nome do árbitro ou anotador')}{pickRow('Função', ['Árbitro','Anotador','Cronometrista','Mesário','Coordenador'], officialRole, setOfficialRole)}{field('WhatsApp (opcional)', officialPhone, setOfficialPhone, '(55) 99999-9999', { keyboardType: 'phone-pad' })}{field('Disponibilidade / observações', availability, setAvailability, 'Ex.: seg-sex à noite, indisponível domingo')}{button('Salvar profissional', addOfficial)}<Text style={styles.section}>Profissionais ({officials.length})</Text>{officials.map(o => card(o.name, `${o.role}${o.phone ? ' • '+o.phone : ''}${o.availability_notes ? '\n'+o.availability_notes : ''}`))}</View>;
    if (tab === 'Jogos') return <View><Text style={styles.section}>Cadastrar jogo</Text>{pickRow('Campeonato', championships, match.championship_id, v => setMatch({...match, championship_id:v}))}{field('Data (AAAA-MM-DD)', match.match_date, v => setMatch({...match, match_date:v}), '2026-10-20')}{field('Horário', match.match_time, v => setMatch({...match, match_time:v}), '19:30')}{field('Local/ginásio', match.venue, v => setMatch({...match, venue:v}), 'Nome do ginásio')}{field('Categoria', match.category, v => setMatch({...match, category:v}), 'Ex.: Adulto Masculino')}{field('Equipe mandante', match.home_team, v => setMatch({...match, home_team:v}), 'Equipe A')}{field('Equipe visitante', match.away_team, v => setMatch({...match, away_team:v}), 'Equipe B')}{pickRow('Árbitro 1', [{id:'',name:'A definir'}, ...officials.filter(o=>['Árbitro','Coordenador'].includes(o.role))], match.referee_1, v => setMatch({...match, referee_1:v}))}{pickRow('Árbitro 2', [{id:'',name:'A definir'}, ...officials.filter(o=>['Árbitro','Coordenador'].includes(o.role))], match.referee_2, v => setMatch({...match, referee_2:v}))}{pickRow('Mesa/anotador', [{id:'',name:'A definir'}, ...officials.filter(o=>['Anotador','Cronometrista','Mesário'].includes(o.role))], match.table_official, v => setMatch({...match, table_official:v}))}{field('Observações', match.notes, v => setMatch({...match, notes:v}), 'Informações adicionais')}{button('Salvar jogo', addMatch)}<Text style={styles.section}>Jogos cadastrados ({matches.length})</Text>{matches.map(m => card(`${m.home_team} x ${m.away_team}`, `${m.match_date} • ${m.match_time} • ${selectedChamp(m.championship_id)}`))}</View>;
    return <View><Text style={styles.section}>Gerar e compartilhar</Text><Text style={styles.subhero}>Escolha um campeonato para filtrar ou compartilhe todos os jogos cadastrados.</Text>{pickRow('Filtrar campeonato', [{id:'',name:'Todos os campeonatos'}, ...championships], shareChamp, setShareChamp)}<View style={styles.preview}><Text style={styles.previewText}>{scaleText}</Text></View>{button('Enviar escala pelo WhatsApp', shareScale)}{button('Atualizar dados', loadAll, true)}</View>;
  }

  if (!session) return <SafeAreaView style={styles.safe}><ExpoStatusBar style="light"/><KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.loginWrap}><View style={styles.logoCircle}><Text style={styles.logoWhistle}>◉</Text></View><Text style={styles.brand}>UNIVERSO DO APITO</Text><Text style={styles.tagline}>GESTÃO DE ARBITRAGEM</Text><Text style={styles.section}>Acesse sua conta</Text>{field('E-mail', email, setEmail, 'seu@email.com', { autoCapitalize: 'none', keyboardType: 'email-address' })}{field('Senha', password, setPassword, 'Mínimo de 6 caracteres', { secureTextEntry: true })}{button(loading ? 'Aguarde...' : 'Entrar', signIn)}{button('Criar conta', signUp, true)}{!isSupabaseConfigured && <Text style={styles.warning}>Para ativar o acesso online, siga os passos do README e configure as chaves do Supabase.</Text>}</KeyboardAvoidingView></SafeAreaView>;

  return <SafeAreaView style={styles.safe}><ExpoStatusBar style="light"/><View style={styles.top}><View><Text style={styles.brandSmall}>UNIVERSO DO APITO</Text><Text style={styles.topSub}>GESTÃO DE ARBITRAGEM</Text></View><TouchableOpacity onPress={() => supabase.auth.signOut()}><Text style={styles.logout}>Sair</Text></TouchableOpacity></View><View style={styles.tabs}>{tabs.map(t => <TouchableOpacity key={t} onPress={() => setTab(t)} style={[styles.tab, tab === t && styles.tabActive]}><Text style={[styles.tabText, tab === t && styles.tabTextActive]}>{t}</Text></TouchableOpacity>)}</View><ScrollView style={styles.body} contentContainerStyle={{ paddingBottom: 40 }}>{content()}</ScrollView></SafeAreaView>;
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:C.bg}, loginWrap:{flex:1,justifyContent:'center',padding:24}, top:{paddingHorizontal:18,paddingVertical:16,flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderBottomWidth:1,borderBottomColor:C.border},
  brand:{fontSize:24,fontWeight:'900',letterSpacing:1.5,color:C.gold,textAlign:'center'}, brandSmall:{fontSize:17,fontWeight:'900',letterSpacing:1,color:C.gold}, tagline:{color:C.muted,textAlign:'center',letterSpacing:2,fontSize:11,marginTop:6,marginBottom:26}, topSub:{color:C.muted,fontSize:10,letterSpacing:1.4,marginTop:3}, logoCircle:{width:74,height:74,borderRadius:37,borderWidth:2,borderColor:C.gold,alignSelf:'center',alignItems:'center',justifyContent:'center',marginBottom:16}, logoWhistle:{fontSize:34,color:C.gold}, logout:{color:C.gold,fontWeight:'700'},
  tabs:{flexDirection:'row',flexWrap:'wrap',paddingHorizontal:10,paddingVertical:8,gap:6,borderBottomWidth:1,borderBottomColor:C.border},tab:{paddingVertical:9,paddingHorizontal:12,borderRadius:9,backgroundColor:C.panel},tabActive:{backgroundColor:C.gold},tabText:{fontSize:12,color:C.muted,fontWeight:'700'},tabTextActive:{color:'#17130A'},
  body:{flex:1,paddingHorizontal:16,paddingTop:18},hero:{color:C.text,fontSize:26,fontWeight:'900',marginBottom:8},subhero:{color:C.muted,fontSize:14,lineHeight:21,marginBottom:16},stats:{flexDirection:'row',gap:8,marginVertical:12},stat:{flex:1,backgroundColor:C.panel,padding:14,borderRadius:12,borderWidth:1,borderColor:C.border},statNum:{color:C.gold,fontSize:25,fontWeight:'900'},statLabel:{color:C.muted,fontSize:11,marginTop:4},section:{color:C.goldLight,fontSize:16,fontWeight:'800',marginTop:18,marginBottom:10},field:{marginBottom:12},label:{color:C.muted,fontSize:12,fontWeight:'700',marginBottom:6},input:{backgroundColor:C.panel,color:C.text,borderColor:C.border,borderWidth:1,borderRadius:10,paddingHorizontal:13,paddingVertical:12,fontSize:14},button:{backgroundColor:C.gold,borderRadius:10,paddingVertical:14,paddingHorizontal:14,alignItems:'center',marginTop:8,marginBottom:8},buttonSecondary:{backgroundColor:C.panel,borderWidth:1,borderColor:C.gold},buttonText:{color:'#17130A',fontWeight:'900',fontSize:14},buttonTextSecondary:{color:C.gold},item:{flexDirection:'row',alignItems:'center',padding:13,backgroundColor:C.panel,borderRadius:10,marginBottom:8,borderWidth:1,borderColor:C.border},itemTitle:{color:C.text,fontWeight:'800',fontSize:14},itemSub:{color:C.muted,fontSize:12,marginTop:4,lineHeight:18},pills:{flexDirection:'row',gap:8,paddingVertical:3},pill:{paddingVertical:9,paddingHorizontal:12,borderRadius:9,backgroundColor:C.panel2,borderWidth:1,borderColor:C.border},pillActive:{backgroundColor:C.gold,borderColor:C.gold},pillText:{color:C.muted,fontSize:12,fontWeight:'700'},pillTextActive:{color:'#17130A'},preview:{backgroundColor:C.panel,padding:14,borderRadius:10,borderWidth:1,borderColor:C.border,marginVertical:10},previewText:{color:C.text,fontSize:13,lineHeight:20},warning:{color:C.goldLight,backgroundColor:'#332B17',padding:12,borderRadius:9,fontSize:12,lineHeight:18,marginTop:12}
});
