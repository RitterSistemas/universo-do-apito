-- Universo do Apito: execute no SQL Editor do seu projeto Supabase.
create extension if not exists pgcrypto;

create table if not exists public.championships (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  name text not null,
  season text,
  created_at timestamptz not null default now()
);

create table if not exists public.officials (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  name text not null,
  role text not null check (role in ('Árbitro','Anotador','Cronometrista','Mesário','Coordenador')),
  phone text,
  availability_notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  championship_id uuid not null references public.championships(id) on delete cascade,
  match_date date not null,
  match_time text not null,
  venue text,
  category text,
  home_team text not null,
  away_team text not null,
  referee_1 uuid references public.officials(id) on delete set null,
  referee_2 uuid references public.officials(id) on delete set null,
  table_official uuid references public.officials(id) on delete set null,
  notes text,
  created_at timestamptz not null default now()
);

alter table public.championships enable row level security;
alter table public.officials enable row level security;
alter table public.matches enable row level security;

drop policy if exists "own championships" on public.championships;
create policy "own championships" on public.championships for all
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

drop policy if exists "own officials" on public.officials;
create policy "own officials" on public.officials for all
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

drop policy if exists "own matches" on public.matches;
create policy "own matches" on public.matches for all
  using (owner_id = auth.uid()) with check (
    owner_id = auth.uid()
    and exists (select 1 from public.championships c where c.id = championship_id and c.owner_id = auth.uid())
  );

create index if not exists championships_owner_idx on public.championships(owner_id);
create index if not exists officials_owner_idx on public.officials(owner_id);
create index if not exists matches_owner_date_idx on public.matches(owner_id, match_date, match_time);
