export const C = {
  bg: '#0B0B0D',
  panel: '#171719',
  panel2: '#202023',
  gold: '#D6A83B',
  goldLight: '#F4D477',
  text: '#F7F4EC',
  muted: '#AAA7A0',
  danger: '#E36B6B',
  green: '#71C995',
  border: '#393735'
};
